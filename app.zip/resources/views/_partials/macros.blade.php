<img src="{{ asset('assets/img/favicon/logo.png') }}" style="width: 200px;">
